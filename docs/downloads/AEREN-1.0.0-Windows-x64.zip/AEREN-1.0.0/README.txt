AEREN 1.0.0 Release Candidate

Rozpakuj całą paczkę i uruchom AEREN.exe. Wymagane: Windows 10/11 x64, .NET Framework 4.6.2 lub nowszy i Microsoft Edge WebView2 Evergreen x64. Plik EXE nie jest podpisany cyfrowo.
Zalecane okno 1280×720 lub większe; minimum testowe 800×600. Minimalne wymagania sprzętowe CPU/RAM nie zostały jeszcze określone na osobnym słabym komputerze.

WASD: ruch; celowanie myszą; Q/E/R: umiejętności; PPM: zdolność postaci; F: moc; Spacja: unik; V: mikstura; C: interakcja; TAB: ekwipunek; Esc: pauza; F11: pełny ekran. Atak automatyczny domyślnie aktywny. Przypisania zmienisz w ustawieniach. Menu: strzałki i Enter. Kontroler — eksperymentalny.

Zapis: %LOCALAPPDATA%\Aeren\Profile. Kopia: Ustawienia → Kopia profilu. W Windows można dodatkowo skopiować cały folder Aeren po zamknięciu gry. Zapisów nie ma w paczce. Postęp z wersji 2.x zachowuje ten sam schemat; przed pierwszym wczytaniem powstaje lokalna kopia. Uszkodzony profil otwiera ekran odzyskiwania zamiast automatycznego resetu.

Gra działa offline po dostępności plików i wymaganych składników. Automatyczne aktualizacje nie są jeszcze udostępnione. Wersję 1.0.0 instaluj ręcznie do osobnego folderu; stary aktualizator 2.x traktuje niższy numer jako starszą wersję.
Błąd: opisz autorowi, co się wydarzyło, i dołącz raport z Ustawienia → Raport diagnostyczny. Raport i historia pozostają lokalnie; nie są wysyłane automatycznie.
Ograniczenia RC: pełny raport gotowości dostarcza autor wraz z wydaniem. Balans i wydajność na słabszych komputerach wymagają testów graczy.
